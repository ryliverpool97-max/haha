const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// --- 状態管理 ---
// waitingQueue: ランダムマッチ待ちのソケットIDリスト
// codeWaiting: 合言葉(ルームコード) -> 待機中のソケットID
// rooms: socket.id -> { roomId, partnerId }
let waitingQueue = [];
const codeWaiting = new Map();
const rooms = new Map();
const nicknames = new Map(); // socket.id -> nickname

function removeFromQueue(id) {
  waitingQueue = waitingQueue.filter((sid) => sid !== id);
}

function removeFromCodeWaiting(id) {
  for (const [code, waitingId] of codeWaiting.entries()) {
    if (waitingId === id) codeWaiting.delete(code);
  }
}

function pairSockets(idA, idB) {
  const roomId = `${idA}-${idB}-${Date.now()}`;
  rooms.set(idA, { roomId, partnerId: idB });
  rooms.set(idB, { roomId, partnerId: idA });

  const nameA = nicknames.get(idA) || '匿名さん';
  const nameB = nicknames.get(idB) || '匿名さん';

  // 片方をcaller(offerを作る側)にする
  io.to(idA).emit('matched', { role: 'caller', partnerName: nameB, roomId });
  io.to(idB).emit('matched', { role: 'callee', partnerName: nameA, roomId });
}

function tryMatch(socketId, roomCode) {
  removeFromQueue(socketId);
  removeFromCodeWaiting(socketId);

  if (roomCode) {
    const waitingId = codeWaiting.get(roomCode);
    if (waitingId && waitingId !== socketId && io.sockets.sockets.get(waitingId)) {
      codeWaiting.delete(roomCode);
      pairSockets(socketId, waitingId);
      return;
    }
    codeWaiting.set(roomCode, socketId);
    io.to(socketId).emit('waiting-for-code');
    return;
  }

  if (waitingQueue.length > 0) {
    const partnerId = waitingQueue.shift();
    // 相手がまだ接続中か確認
    if (io.sockets.sockets.get(partnerId)) {
      pairSockets(socketId, partnerId);
      return;
    }
  }
  waitingQueue.push(socketId);
}

function leaveRoom(socketId, notifyPartner = true) {
  const info = rooms.get(socketId);
  if (info) {
    rooms.delete(socketId);
    const partnerInfo = rooms.get(info.partnerId);
    if (partnerInfo && partnerInfo.partnerId === socketId) {
      rooms.delete(info.partnerId);
      if (notifyPartner) {
        io.to(info.partnerId).emit('partner-left');
      }
    }
  }
  removeFromQueue(socketId);
  removeFromCodeWaiting(socketId);
}

// 通報ログ(簡易)。本番運用では人によるモデレーション体制と併用してください。
const REPORT_LOG = path.join(__dirname, 'reports.log');

io.on('connection', (socket) => {
  socket.on('set-nickname', (nickname) => {
    const clean = (nickname || '').toString().slice(0, 20).trim();
    nicknames.set(socket.id, clean || '匿名さん');
  });

  socket.on('find-partner', (roomCode) => {
    leaveRoom(socket.id, true);
    const code = (roomCode || '').toString().trim().toUpperCase().slice(0, 12) || null;
    tryMatch(socket.id, code);
  });

  socket.on('offer', (data) => {
    const info = rooms.get(socket.id);
    if (info) io.to(info.partnerId).emit('offer', data);
  });

  socket.on('answer', (data) => {
    const info = rooms.get(socket.id);
    if (info) io.to(info.partnerId).emit('answer', data);
  });

  socket.on('ice-candidate', (data) => {
    const info = rooms.get(socket.id);
    if (info) io.to(info.partnerId).emit('ice-candidate', data);
  });

  socket.on('chat-message', (text) => {
    const info = rooms.get(socket.id);
    if (!info) return;
    const clean = (text || '').toString().slice(0, 1000);
    io.to(info.partnerId).emit('chat-message', { text: clean, from: 'partner' });
  });

  socket.on('skip', () => {
    leaveRoom(socket.id, true);
    tryMatch(socket.id, null); // 「次へ」は常にランダムマッチに戻る
  });

  socket.on('leave', () => {
    leaveRoom(socket.id, true);
  });

  socket.on('report', (reason) => {
    const info = rooms.get(socket.id);
    const line = `${new Date().toISOString()} reporter=${socket.id} reported=${info ? info.partnerId : 'unknown'} reason=${JSON.stringify((reason || '').toString().slice(0, 300))}\n`;
    fs.appendFile(REPORT_LOG, line, () => {});
    // 通報したら即座にその相手との通話を切る
    leaveRoom(socket.id, true);
  });

  socket.on('disconnect', () => {
    leaveRoom(socket.id, true);
    nicknames.delete(socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
