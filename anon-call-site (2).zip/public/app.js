const socket = io();

// ---- DOM ----
const screens = {
  entry: document.getElementById('screen-entry'),
  searching: document.getElementById('screen-searching'),
  call: document.getElementById('screen-call'),
  ended: document.getElementById('screen-ended'),
};
const nicknameInput = document.getElementById('nickname');
const roomCodeInput = document.getElementById('room-code');
const btnMakeInvite = document.getElementById('btn-make-invite');
const inviteBox = document.getElementById('invite-box');
const inviteLinkInput = document.getElementById('invite-link');
const btnCopyInvite = document.getElementById('btn-copy-invite');
const agreeCheckbox = document.getElementById('agree-age');
const btnStart = document.getElementById('btn-start');
const permissionNote = document.getElementById('permission-note');
const btnCancelSearch = document.getElementById('btn-cancel-search');
const searchingText = document.getElementById('searching-text');
const searchingInviteBox = document.getElementById('searching-invite-box');
const searchingInviteLink = document.getElementById('searching-invite-link');
const btnCopyInvite2 = document.getElementById('btn-copy-invite-2');

const partnerNameEl = document.getElementById('partner-name');
const callTimerEl = document.getElementById('call-timer');
const localVideo = document.getElementById('local-video');
const remoteVideo = document.getElementById('remote-video');
const chatLog = document.getElementById('chat-log');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');

const btnMic = document.getElementById('btn-mic');
const btnCam = document.getElementById('btn-cam');
const btnSkip = document.getElementById('btn-skip');
const btnReport = document.getElementById('btn-report');
const btnEnd = document.getElementById('btn-end');

const endedMessage = document.getElementById('ended-message');
const btnAgain = document.getElementById('btn-again');
const btnHome = document.getElementById('btn-home');

const reportModal = document.getElementById('report-modal');
const reportReason = document.getElementById('report-reason');
const reportCancel = document.getElementById('report-cancel');
const reportSubmit = document.getElementById('report-submit');

const guidelinesModal = document.getElementById('guidelines-modal');
const openGuidelines = document.getElementById('open-guidelines');
const guidelinesClose = document.getElementById('guidelines-close');

// ---- 状態 ----
let localStream = null;
let pc = null;
let micOn = true;
let camOn = true;
let timerInterval = null;
let timerSeconds = 0;
let currentRoomCode = null;
const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

function showScreen(name) {
  Object.values(screens).forEach((el) => el.classList.remove('active'));
  screens[name].classList.add('active');
}

// ---- 入口画面 ----
function updateStartButton() {
  btnStart.disabled = !agreeCheckbox.checked;
}
agreeCheckbox.addEventListener('change', updateStartButton);

function buildInviteUrl(code) {
  const url = new URL(window.location.href);
  url.search = '';
  url.searchParams.set('room', code);
  return url.toString();
}

function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 紛らわしい文字を除外
  let code = '';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function showInvite(code) {
  const url = buildInviteUrl(code);
  inviteLinkInput.value = url;
  inviteBox.classList.remove('hidden');
}

btnMakeInvite.addEventListener('click', () => {
  let code = roomCodeInput.value.trim().toUpperCase();
  if (!code) {
    code = generateRoomCode();
    roomCodeInput.value = code;
  }
  showInvite(code);
});

async function copyToClipboard(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (e) {
    // クリップボードAPIが使えない場合は選択状態にするだけ
  }
  const original = btn.textContent;
  btn.textContent = 'コピーしました';
  btn.classList.add('copied');
  setTimeout(() => {
    btn.textContent = original;
    btn.classList.remove('copied');
  }, 1800);
}

btnCopyInvite.addEventListener('click', () => copyToClipboard(inviteLinkInput.value, btnCopyInvite));
btnCopyInvite2.addEventListener('click', () => copyToClipboard(searchingInviteLink.value, btnCopyInvite2));

// URLに ?room=コード がある場合は自動で入力しておく(招待から開いた側)
(function prefillRoomFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const room = params.get('room');
  if (room) {
    roomCodeInput.value = room.toUpperCase();
  }
})();

openGuidelines.addEventListener('click', () => guidelinesModal.classList.remove('hidden'));
guidelinesClose.addEventListener('click', () => guidelinesModal.classList.add('hidden'));

btnStart.addEventListener('click', async () => {
  permissionNote.textContent = '';
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localVideo.srcObject = localStream;
  } catch (err) {
    permissionNote.textContent = 'カメラ・マイクへのアクセスを許可してください。';
    return;
  }
  socket.emit('set-nickname', nicknameInput.value);
  startSearching(roomCodeInput.value.trim().toUpperCase());
});

function startSearching(code) {
  currentRoomCode = code || null;
  showScreen('searching');
  if (currentRoomCode) {
    searchingText.textContent = `合言葉「${currentRoomCode}」で待っています…`;
    searchingInviteLink.value = buildInviteUrl(currentRoomCode);
    searchingInviteBox.classList.remove('hidden');
  } else {
    searchingText.innerHTML = '周波数をスキャン中<span class="dots"><span>.</span><span>.</span><span>.</span></span>';
    searchingInviteBox.classList.add('hidden');
  }
  socket.emit('find-partner', currentRoomCode);
}

btnCancelSearch.addEventListener('click', () => {
  socket.emit('leave');
  stopLocalStream();
  showScreen('entry');
});

// ---- マッチング成立 ----
socket.on('matched', async ({ role, partnerName }) => {
  partnerNameEl.textContent = partnerName;
  clearChat();
  addSystemMessage(`${partnerName} さんと繋がりました`);
  showScreen('call');
  startTimer();
  await setupPeerConnection();

  if (role === 'caller') {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit('offer', offer);
  }
});

async function setupPeerConnection() {
  pc = new RTCPeerConnection(ICE_SERVERS);

  localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));

  pc.ontrack = (event) => {
    remoteVideo.srcObject = event.streams[0];
  };

  pc.onicecandidate = (event) => {
    if (event.candidate) socket.emit('ice-candidate', event.candidate);
  };
}

socket.on('offer', async (offer) => {
  if (!pc) await setupPeerConnection();
  await pc.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('answer', answer);
});

socket.on('answer', async (answer) => {
  await pc.setRemoteDescription(new RTCSessionDescription(answer));
});

socket.on('ice-candidate', async (candidate) => {
  try {
    await pc.addIceCandidate(candidate);
  } catch (e) { /* ICE候補追加の失敗は無視しても致命的ではない */ }
});

socket.on('partner-left', () => {
  endCallUI('相手が退出しました');
});

// ---- チャット ----
chatForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  addChatMessage(text, 'me');
  socket.emit('chat-message', text);
  chatInput.value = '';
});

socket.on('chat-message', ({ text }) => {
  addChatMessage(text, 'partner');
});

function addChatMessage(text, who) {
  const div = document.createElement('div');
  div.className = `chat-msg ${who}`;
  div.textContent = text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}
function addSystemMessage(text) {
  const div = document.createElement('div');
  div.className = 'chat-msg system';
  div.textContent = text;
  chatLog.appendChild(div);
}
function clearChat() { chatLog.innerHTML = ''; }

// ---- コントロール ----
btnMic.addEventListener('click', () => {
  if (!localStream) return;
  micOn = !micOn;
  localStream.getAudioTracks().forEach((t) => (t.enabled = micOn));
  btnMic.textContent = micOn ? '🎙️' : '🔇';
  btnMic.classList.toggle('active-off', !micOn);
});

btnCam.addEventListener('click', () => {
  if (!localStream) return;
  camOn = !camOn;
  localStream.getVideoTracks().forEach((t) => (t.enabled = camOn));
  btnCam.textContent = camOn ? '📷' : '🚫';
  btnCam.classList.toggle('active-off', !camOn);
});

btnSkip.addEventListener('click', () => {
  teardownPeerConnection();
  socket.emit('skip'); // 「次へ」は常にランダムな相手に戻る
  currentRoomCode = null;
  searchingText.innerHTML = '周波数をスキャン中<span class="dots"><span>.</span><span>.</span><span>.</span></span>';
  searchingInviteBox.classList.add('hidden');
  showScreen('searching');
});

btnEnd.addEventListener('click', () => {
  socket.emit('leave');
  endCallUI('通話を終了しました');
});

btnReport.addEventListener('click', () => {
  reportModal.classList.remove('hidden');
});
reportCancel.addEventListener('click', () => reportModal.classList.add('hidden'));
reportSubmit.addEventListener('click', () => {
  socket.emit('report', reportReason.value);
  reportReason.value = '';
  reportModal.classList.add('hidden');
  endCallUI('通報を受け付け、通話を終了しました');
});

// ---- 終了処理 ----
function endCallUI(message) {
  teardownPeerConnection();
  stopTimer();
  endedMessage.textContent = message;
  showScreen('ended');
}

btnAgain.addEventListener('click', async () => {
  if (!localStream) {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      localVideo.srcObject = localStream;
    } catch (e) {
      showScreen('entry');
      return;
    }
  }
  startSearching(currentRoomCode); // 同じ合言葉ならまた同じ友達と繋がりやすい
});

btnHome.addEventListener('click', () => {
  stopLocalStream();
  showScreen('entry');
});

function teardownPeerConnection() {
  if (pc) {
    pc.close();
    pc = null;
  }
  remoteVideo.srcObject = null;
}

function stopLocalStream() {
  if (localStream) {
    localStream.getTracks().forEach((t) => t.stop());
    localStream = null;
  }
}

// ---- タイマー ----
function startTimer() {
  timerSeconds = 0;
  callTimerEl.textContent = '00:00';
  timerInterval = setInterval(() => {
    timerSeconds += 1;
    const m = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
    const s = String(timerSeconds % 60).padStart(2, '0');
    callTimerEl.textContent = `${m}:${s}`;
  }, 1000);
}
function stopTimer() {
  clearInterval(timerInterval);
}
